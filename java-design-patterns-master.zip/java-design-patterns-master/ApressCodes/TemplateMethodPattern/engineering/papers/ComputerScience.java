package engineering.papers;

public class ComputerScience extends BasicEngineering
{
	@Override
	public void SpecialPaper()
    {
	   System.out.println("Object Oriented Programming");
    }
}