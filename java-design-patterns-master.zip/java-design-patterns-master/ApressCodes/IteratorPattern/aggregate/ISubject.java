package aggregate;
import iterator.*;

public interface ISubject 
{
	public IIterator CreateIterator();
}
